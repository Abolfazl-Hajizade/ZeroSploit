
from os import system

system("python manage.py runserver")


